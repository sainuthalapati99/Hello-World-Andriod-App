
package com.example.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText yourName;
    private TextView outputName;
    private TextView outputName2;

    public void printHello(View v) {

        Button helloButton = (Button) v;
        ((Button)v).setText("You clicked Hello");

        yourName = (EditText) findViewById(R.id.inputText);
        outputName = (TextView) findViewById(R.id.outputText1);
        outputName.setText("Hello, "+ yourName.getText());
        outputName.setVisibility(View.VISIBLE);

    }
    public void printGoodBye(View v) {

        Button goodbyeButton = (Button) v;
        ((Button) v).setText("You clicked GoodBye");

        yourName = (EditText) findViewById(R.id.inputText);
        outputName2 = (TextView) findViewById(R.id.outputText1);
        outputName2.setText("Goodbye, " + yourName.getText());
        outputName2.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}